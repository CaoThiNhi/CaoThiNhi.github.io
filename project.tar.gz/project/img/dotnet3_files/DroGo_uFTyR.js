if (self.CavalryLogger) { CavalryLogger.start_js(["kIHQG"]); }

__d("XChatEmojiSettingsController",["XController"],(function a(b,c,d,e,f,g){c.__markCompiled&&c.__markCompiled();f.exports=c("XController").create("\/chat\/emoji_settings\/",{__asyncDialog:{type:"Int"}});}),null);