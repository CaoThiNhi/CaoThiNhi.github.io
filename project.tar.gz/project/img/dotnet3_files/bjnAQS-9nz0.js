if (self.CavalryLogger) { CavalryLogger.start_js(["v7UFs"]); }

__d('EventReminderDispatcher',['ExplicitRegistrationDispatcher'],(function a(b,c,d,e,f,g){'use strict';if(c.__markCompiled)c.__markCompiled();f.exports=new (c('ExplicitRegistrationDispatcher'))({strict:false});}),null);