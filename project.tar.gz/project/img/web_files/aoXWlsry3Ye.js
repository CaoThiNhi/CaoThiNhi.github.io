if (self.CavalryLogger) { CavalryLogger.start_js(["tdPAF"]); }

__d("OmniMActionType",[],(function a(b,c,d,e,f,g){c.__markCompiled&&c.__markCompiled();f.exports={CREATE_EVENT:1,LOCATION:2,PAYMENT:3,POLL:4,STICKER:5,TEXT:6,TRANSPORTATION:7,ORDER_FOOD:8,MAKE_RESERVATION:9,SCHEDULE_CALL:10,LIVE_LOCATION:11};}),null);