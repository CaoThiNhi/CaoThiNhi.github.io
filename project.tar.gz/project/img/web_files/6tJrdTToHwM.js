if (self.CavalryLogger) { CavalryLogger.start_js(["OpkwY"]); }

__d("XKeywordSubscribeController",["XController"],(function a(b,c,d,e,f,g){c.__markCompiled&&c.__markCompiled();f.exports=c("XController").create("\/keyword\/controller\/{?keyword_id}\/",{keyword_id:{type:"String"}});}),null);